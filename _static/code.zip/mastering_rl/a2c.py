# Source: https://github.com/bentrevett/pytorch-rl/blob/master/3%20-%20Advantage%20Actor%20Critic%20(A2C)%20%5BCartPole%5D.ipynb

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.distributions as distributions

from deep_nn_policy import DeepNeuralNetworkPolicy

from deep_value_function import DeepValueFunction

import matplotlib.pyplot as plt
import numpy as np
import gym
#train_env = gym.make('Freeway-ramDeterministic-v4')
#test_env = gym.make('Freeway-ramDeterministic-v4')
#train_env = gym.make('ALE/Frogger-ram-v5')
#test_env = gym.make('ALE/Frogger-ram-v5')
#train_env = gym.make('Riverraid-ramNoFrameskip-v4')
#test_env = gym.make('Riverraid-ramNoFrameskip-v4')
train_env = gym.make('Frostbite-ramNoFrameskip-v4')
test_env = gym.make('Frostbite-ramNoFrameskip-v4')
#train_env = gym.make('CartPole-v1')
#test_env = gym.make('CartPole-v1')
SEED = 1234

#train_env.seed(SEED);
#test_env.seed(SEED+1)
#np.random.seed(SEED);
#torch.manual_seed(SEED);

class MLP(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, dropout = 0.5):
        super().__init__()

        self.fc_1 = nn.Linear(input_dim, hidden_dim)
        self.fc_2 = nn.Linear(hidden_dim, output_dim)
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x):
        x = self.fc_1(x)
        x = self.dropout(x)
        x = F.relu(x)
        x = self.fc_2(x)
        return x

class ActorCritic(nn.Module):
    def __init__(self, actor, critic):
        super().__init__()
        
        self.actor = actor
        self.critic = critic
        
    def forward(self, state):
        action_pred = self.actor.policy_network([state])
        value_pred = self.critic(state)
        
        return action_pred, value_pred

INPUT_DIM = train_env.observation_space.shape[0]
HIDDEN_DIM = 128
OUTPUT_DIM = test_env.action_space.n


#actor = MLP(INPUT_DIM, HIDDEN_DIM, OUTPUT_DIM)
actor = DeepNeuralNetworkPolicy(INPUT_DIM, OUTPUT_DIM, hidden_dim=128)
#
# critic = MLP(INPUT_DIM, HIDDEN_DIM, 1)
critic = DeepValueFunction(INPUT_DIM, hidden_dim=128)

policy = ActorCritic(actor, critic)
def init_weights(m):
    if type(m) == nn.Linear:
        torch.nn.init.xavier_normal_(m.weight)
        m.bias.data.fill_(0)
policy.apply(init_weights)

LEARNING_RATE = 0.001

optimizer = None #optim.Adam(policy.parameters(), lr = LEARNING_RATE)
def train(env, policy, optimizer, discount_factor):
    
    #policy.train()
    
    log_prob_actions = []
    values = []
    rewards = []
    states = []
    actions = []
    done = False
    episode_reward = 0

    state, _ = env.reset()

    step = 0
    while not done:

        state_tensor = torch.FloatTensor(state) #.unsqueeze(0)

        #action_pred = actor.policy_network(state_tensor)
        value_pred = critic.value_network(state_tensor)
        #action_prob = F.softmax(action_pred, dim = -1)
        #print(action_pred)
        #dist = distributions.Categorical(action_prob)

        #action = dist.sample()
        num_actions = env.action_space.n
        available_actions = list(range(num_actions))
        action = actor.select_action(state_tensor, available_actions)
        #log_prob_action = dist.log_prob(action)
        
        
        states.append(state)
        actions.append(action)
        
        state, reward, done, _, _ = env.step(action)

        #log_prob_actions.append(log_prob_action)
        values.append(value_pred)
        rewards.append(reward)
        episode_reward += reward

        if step == 500:
            done = True

        step += 1

    #log_prob_actions = torch.stack(log_prob_actions)
    values = torch.cat(values).squeeze(-1)
    
    returns = calculate_returns(rewards, discount_factor)
    advantages = calculate_advantages(returns, values)
    
    policy_loss, value_loss = update_policy(states, actions, advantages, log_prob_actions, returns, values, optimizer)

    return policy_loss, value_loss, episode_reward

def calculate_returns(rewards, discount_factor, normalize = False):
    
    returns = []
    R = 0
    
    for r in reversed(rewards):
        R = r + R * discount_factor
        returns.insert(0, R)
        
    returns = torch.tensor(returns)
    
    if normalize:
        
        returns = (returns - returns.mean()) / returns.std()
        
    return returns

def calculate_advantages(returns, values, normalize = False):
    
    advantages = returns - values
    
    if normalize:
        
        advantages = (advantages - advantages.mean()) / advantages.std()
        
    return advantages

def update_policy(states, actions, advantages, log_prob_actions, returns, values, optimizer):
        
    advantages = advantages.detach()
    returns = returns.detach()

    policy_loss = policy.actor.update(states, actions, advantages)
    #policy_loss = - (advantages * log_prob_actions).sum()
    
    #value_loss = F.smooth_l1_loss(returns, values).sum()
    value_loss = policy.critic.batch_update(states, advantages)
        
    #optimizer.zero_grad()
    
    #policy_loss.backward()
    #value_loss.backward()
    
    #optimizer.step()
    
    return policy_loss.item(), value_loss.item()

def evaluate(env, policy):
    
    rewards = []
    done = False
    episode_reward = 0

    state, _ = env.reset()

    step = 0
    while not done:

        state = torch.FloatTensor(state) #.unsqueeze(0)
        
        with torch.no_grad():
        
            action_pred = policy.actor.policy_network(state)

            action_prob = F.softmax(action_pred, dim = -1)
                
        action = torch.argmax(action_prob, dim = -1)
                
        state, reward, done, _, _ = env.step(action.item())

        episode_reward += reward

        if step == 500:
           done = True
        step += 1
        
    return episode_reward

MAX_EPISODES = 5000
DISCOUNT_FACTOR = 0.99
N_TRIALS = 25
REWARD_THRESHOLD = 475
PRINT_EVERY = 10

train_rewards = []
test_rewards = []

for episode in range(1, MAX_EPISODES+1):
    
    policy_loss, value_loss, train_reward = train(train_env, policy, optimizer, DISCOUNT_FACTOR)
    
    test_reward = evaluate(test_env, policy)
    
    train_rewards.append(train_reward)
    test_rewards.append(test_reward)
    
    mean_train_rewards = np.mean(train_rewards[-N_TRIALS:])
    mean_test_rewards = np.mean(test_rewards[-N_TRIALS:])
    
    if episode % PRINT_EVERY == 0:
    
        print(f'| Episode: {episode:3} | Mean Train Rewards: {mean_train_rewards:5.1f} | Mean Test Rewards: {mean_test_rewards:5.1f} |')
    
    """
    if mean_test_rewards >= REWARD_THRESHOLD:
        
        print(f'Reached reward threshold in {episode} episodes')
        
        break
    """

plt.figure(figsize=(12,8))
plt.plot(test_rewards, label='Test Reward')
plt.plot(train_rewards, label='Train Reward')
plt.xlabel('Episode', fontsize=20)
plt.ylabel('Reward', fontsize=20)
plt.hlines(REWARD_THRESHOLD, 0, len(test_rewards), color='r')
plt.legend(loc='lower right')
plt.grid()
