import torch
import torch.nn as nn
from torch.distributions.categorical import Categorical
from torch.optim import Adam
import torch.nn.functional as F

from policy import StochasticPolicy


class DeepCNNPolicy(StochasticPolicy):

    def __init__(self, input_channels, action_space, alpha=0.0001, stochastic=True):
        self.input_channels = input_channels  # For RGB, this will be 3
        self.action_space = action_space

        # Define the CNN layers
        self.policy_network = nn.Sequential(
            # Convolutional layers: input size is (C, H, W) where C is channels (e.g., 3 for RGB)
            nn.Conv2d(in_channels=self.input_channels, out_channels=32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(in_channels=32, out_channels=64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1),
            nn.ReLU(),

            # Flatten the output of the CNN before feeding into fully connected layers
            nn.Flatten(),

            # Fully connected layers
            nn.Linear(in_features=64 * 7 * 7, out_features=512),  # Adjust the size based on input image size
            nn.ReLU(),
            nn.Linear(in_features=512, out_features=self.action_space),
        )

        # Initialize weights using Xavier initialization
        self._initialize_weights()

        # Optimizer for the policy network
        self.optimiser = Adam(self.policy_network.parameters(), lr=alpha)

        # Whether to select actions stochastically or deterministically
        self.stochastic = stochastic

    def _initialize_weights(self):
        for layer in self.policy_network:
            if isinstance(layer, nn.Conv2d) or isinstance(layer, nn.Linear):
                nn.init.xavier_uniform_(layer.weight)
                nn.init.zeros_(layer.bias)

    """ Select an action using a forward pass through the network """
    def select_action(self, state, actions):
        # Convert the state into a tensor and add a batch dimension (state: [C, H, W])
        state = torch.as_tensor(state, dtype=torch.float32).unsqueeze(0)  # Add batch dim

        action_logits = self.policy_network(state)

        # Mask out unavailable actions
        mask = torch.full_like(action_logits, float('-inf'))
        mask[actions] = 0
        masked_logits = action_logits + mask

        action_distribution = Categorical(logits=masked_logits)
        if self.stochastic:
            action = action_distribution.sample()
        else:
            action_probabilities = torch.softmax(masked_logits, dim=-1)
            action = torch.argmax(action_probabilities)
        return action.item()

    """ Get the probability of an action being selected in a state """
    def get_probability(self, state, action):
        state = torch.as_tensor(state, dtype=torch.float32).unsqueeze(0)  # Add batch dim
        with torch.no_grad():
            action_logits = self.policy_network(state)

        probabilities = F.softmax(action_logits, dim=-1).tolist()
        return probabilities[0][action]

    def evaluate_actions(self, states, actions):
        action_logits = self.policy_network(states)
        action_distribution = Categorical(logits=action_logits)
        log_prob = action_distribution.log_prob(actions.squeeze(-1))
        return log_prob

    def update(self, states, actions, deltas):
        states_tensor = torch.as_tensor(states, dtype=torch.float32)
        actions_tensor = torch.as_tensor(actions)
        deltas_tensor = torch.as_tensor(deltas, dtype=torch.float32)

        action_log_probs = self.evaluate_actions(states_tensor, actions_tensor)

        # Loss function using negative log-probabilities
        loss = -(action_log_probs * deltas).sum()
        self.optimiser.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_value_(self.policy_network.parameters(), 100)

        # Take an optimization step
        self.optimiser.step()
        return loss

    def save(self, filename):
        torch.save(self.policy_network.state_dict(), filename)

    @classmethod
    def load(cls, input_channels, action_space, filename):
        policy = cls(input_channels, action_space)
        policy.policy_network.load_state_dict(torch.load(filename))
        return policy
