from mastering_rl.learners.n_step_qlearning import NStepQLearning
from mastering_rl.learners.qlearning import QLearning
from mastering_rl.markov_decision_processes.gridworld import GridWorld
from mastering_rl.multi_armed_bandit.epsilon_greedy import EpsilonGreedy
from mastering_rl.policies.q_policy import QPolicy
from mastering_rl.qfunctions.qtable import QTable

# Illustrate the n-step feedback from the first episode
mdp = GridWorld(noise=0.0, goals=[((3, 2), 1)])
qfunction = QTable(alpha=0.4)
NStepQLearning(mdp, EpsilonGreedy(), qfunction, 5).execute(episodes=1)
print(mdp.q_function_to_string(qfunction))

mdp = GridWorld(noise=0.0, goals=[((3, 2), 1)])
qfunction = QTable(alpha=0.4)
QLearning(mdp, EpsilonGreedy(), qfunction).execute(episodes=1000)
print(mdp.q_function_to_string(qfunction))

mdp = GridWorld(noise=0.0, goals=[((3, 2), 1)])
qfunction = QTable(alpha=0.4)
NStepQLearning(mdp, EpsilonGreedy(), qfunction, 5).execute(episodes=1000)
print(mdp.q_function_to_string(qfunction))

policy = QPolicy(qfunction)
print(mdp.policy_to_string(policy))
