import random
import numpy as np
from collections import deque, namedtuple
from itertools import count


from mastering_rl.learners.model_free_learner import ModelFreeLearner

Transition = namedtuple(
    "Transition", ("state", "action", "next_state", "reward", "done", "delta")
)


class ReplayMemory:
    def __init__(self, memory_size=10000):
        self.memory = deque([], maxlen=memory_size)

    def push(self, state, action, next_state, reward, done, delta):
        self.memory.append(Transition(state, action, next_state, reward, done, delta))

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)


class PrioritisedReplayMemory:
    def __init__(self, memory_size=10000, alpha=0.6):
        self.memory = deque([], maxlen=memory_size)
        self.priorities = deque([], maxlen=memory_size)
        self.alpha = alpha

    def push(self, state, action, next_state, reward, done, delta=1.0):
        self.memory.append(Transition(state, action, next_state, reward, done, delta))
        self.priorities.append(abs(delta) ** self.alpha)

    def sample(self, batch_size, beta=0.4):
        priorities = np.array(self.priorities)
        # Add a small amount to present divide by zero
        epsilon = 0.001
        priorities = priorities + epsilon
        probs = priorities / priorities.sum()
        indices = np.random.choice(len(self.memory), batch_size, p=probs)
        samples = [self.memory[idx] for idx in indices]
        importance_sampling_weights = (len(self.memory) * probs[indices]) ** (-beta)
        importance_sampling_weights /= importance_sampling_weights.max()
        return samples #, indices, importance_sampling_weights

    def update_priorities(self, indices, errors):
        for idx, error in zip(indices, errors):
            self.priorities[idx] = error ** self.alpha

    def __len__(self):
        return len(self.memory)

class ExperienceReplayLearner(ModelFreeLearner):
    def __init__(
        self,
        mdp,
        bandit,
        policy_qfunction,
        target_qfunction,
        memory=ReplayMemory(),
        batch_size=64,
        memory_size=10000,
        update_period=4,
    ):
        self.mdp = mdp
        self.bandit = bandit
        self.policy_qfunction = policy_qfunction
        self.target_qfunction = target_qfunction
        self.batch_size = batch_size
        self.memory = memory
        self.update_period = update_period
        self.target_qfunction.soft_update(self.policy_qfunction)

    def execute(self, episodes=100, max_episode_length=float("inf")):

        episode_rewards = []
        for episode in range(episodes):
            state = self.mdp.get_initial_state()
            actions = self.mdp.get_actions(state)
            action = self.bandit.select(state, actions, self.policy_qfunction)
            episode_reward = 0
            for step in count():
                (next_state, reward, done) = self.mdp.execute(state, action)
                actions = self.mdp.get_actions(next_state)
                next_action = self.bandit.select(
                    next_state, actions, self.policy_qfunction
                )

                delta = self.get_delta(reward, state, action, next_state, done)
                self.memory.push(state, action, next_state, reward, done, delta)

                # Perform an update on the policy qfunction using a batch
                if len(self.memory) >= self.batch_size:
                    transitions = self.memory.sample(self.batch_size)
                    batch = Transition(*zip(*transitions))

                    deltas = self.get_deltas(
                        batch.reward,
                        batch.state,
                        batch.action,
                        batch.next_state,
                        batch.done,
                    )

                    self.policy_qfunction.batch_update(
                        batch.state, batch.action, deltas
                    )

                if step % self.update_period == 0:
                    # Soft update of the target Q-function
                    self.target_qfunction.soft_update(self.policy_qfunction)

                # Move to the next state
                state = next_state
                action = next_action
                episode_reward += reward * (self.mdp.discount_factor ** step)

                if done or step == max_episode_length:
                    break

            episode_rewards.append(episode_reward)
        return episode_rewards

    """ Calculate the deltas for the update """

    def get_deltas(self, rewards, states, actions, next_states, dones):
        q_values = self.policy_qfunction.get_q_values(states, actions)
        next_state_q_values = self.state_values(next_states, actions)
        deltas = [
            (
                reward + (self.mdp.get_discount_factor() * next_state_q_value) - q_value
                if not done
                else (reward - q_value)
            )
            for reward, next_state_q_value, q_value, done in zip(
                rewards, next_state_q_values, q_values, dones
            )
        ]
        return deltas

    def get_delta(self, reward, state, action, next_state, done):
        q_value = self.policy_qfunction.get_q_values([state], [action])[0]
        next_state_q_value = self.state_values([next_state], [action])[0]
        deltas = (
            reward + (self.mdp.get_discount_factor() * next_state_q_value) - q_value
            if not done
            else (reward - q_value)
        )
        return deltas

    def state_values(self, states, actions):
        return self.target_qfunction.get_max_q_values(states)
