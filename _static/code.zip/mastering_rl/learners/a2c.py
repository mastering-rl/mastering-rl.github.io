import random
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions.categorical import Categorical
from torch.optim import Adam
import gym
from itertools import count

class QFunction:
    def update(self, state, action, delta):
        raise NotImplementedError

    def batch_update(self, states, actions, deltas):
        raise NotImplementedError

    def get_q_value(self, state, action):
        raise NotImplementedError

    def save_policy(self, filename):
        raise NotImplementedError

    def load_policy(self, filename):
        raise NotImplementedError

    def get_argmax_q(self, state, actions):
        (argmax_q, max_q) = self.get_max_pair(state, actions)
        return argmax_q

    def get_max_q(self, state, actions):
        (argmax_q, max_q) = self.get_max_pair(state, actions)
        return max_q

    def get_max_pair(self, state, actions):
        max_q = float("-inf")
        max_actions = []
        for action in actions:
            value = self.get_q_value(state, action)
            if value > max_q:
                max_actions = [action]
                max_q = value
            elif value == max_q:
                max_actions += [action]
        arg_max_q = random.choice(max_actions)
        return (arg_max_q, max_q)

class DeepNeuralNetworkPolicy(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(DeepNeuralNetworkPolicy, self).__init__()
        self.fc1 = nn.Linear(state_dim, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, action_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return F.softmax(x, dim=-1)

    def select_action(self, state, actions):
        state = torch.FloatTensor(state).unsqueeze(0)
        probs = self.forward(state)
        m = Categorical(probs)
        action = m.sample()
        return action.item(), m.log_prob(action)

    def get_probability(self, state, action):
        state = torch.FloatTensor(state).unsqueeze(0)
        probs = self.forward(state)
        return probs[0, action].item()

    def evaluate_actions(self, states, actions):
        states = torch.FloatTensor(states)
        actions = torch.FloatTensor(actions)
        probs = self.forward(states)
        m = Categorical(probs)
        log_probs = m.log_prob(actions)
        entropy = m.entropy()
        return log_probs, entropy

    def update(self, states, actions, deltas):
        optimizer = Adam(self.parameters(), lr=1e-3)
        log_probs, entropy = self.evaluate_actions(states, actions)
        loss = -(log_probs * deltas).mean() - 0.01 * entropy.mean()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

class ActorCriticAgent:
    def __init__(self, state_dim, action_dim):
        self.policy = DeepNeuralNetworkPolicy(state_dim, action_dim)
        self.value_function = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
        self.optimizer = Adam(list(self.policy.parameters()) + list(self.value_function.parameters()), lr=1e-3)

    def execute(self, episodes=100, max_episode_length=float("inf")):
        env = gym.make('CartPole-v1')
        for episode in range(episodes):
            state, _ = env.reset()
            episode_reward = 0
            for step in count():
                action, log_prob = self.policy.select_action(state, range(env.action_space.n))
                next_state, reward, done, _, _ = env.step(action)
                episode_reward += reward

                value = self.value_function(torch.FloatTensor(state).unsqueeze(0))
                next_value = self.value_function(torch.FloatTensor(next_state).unsqueeze(0))
                delta = reward + (1 - done) * next_value - value
                self.policy.update([state], [action], delta.detach())
                self.value_function.zero_grad()
                delta.backward()
                self.optimizer.step()

                state = next_state
                if done or step == max_episode_length:
                    break
            print(f"Episode {episode + 1}: Reward = {episode_reward}")

if __name__ == "__main__":
    env = gym.make('CartPole-v1')
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n
    agent = ActorCriticAgent(state_dim, action_dim)
    agent.execute(episodes=500)